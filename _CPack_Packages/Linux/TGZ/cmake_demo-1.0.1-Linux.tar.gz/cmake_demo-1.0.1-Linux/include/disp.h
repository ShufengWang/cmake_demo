#include <iostream>
#include <string>
using namespace std;

void disp(string s);
void disp(string s1, string s2);
