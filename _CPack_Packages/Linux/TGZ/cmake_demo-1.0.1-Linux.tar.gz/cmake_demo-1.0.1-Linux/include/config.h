//predefine valuable
/* #undef HAVE_DISP */
#define USE_UTILS

//version info
#define demo_VERSION_MAJOR 1
#define demo_VERSION_MINOR 0
